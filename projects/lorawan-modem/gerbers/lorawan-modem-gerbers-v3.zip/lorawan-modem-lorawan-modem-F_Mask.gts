%TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+dfsg-1build4*%
%TF.CreationDate,2026-05-07T22:14:19+05:00*%
%TF.ProjectId,lorawan-modem,6c6f7261-7761-46e2-9d6d-6f64656d2e6b,0.1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+dfsg-1build4) date 2026-05-07 22:14:19*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,*%
X5000000Y-5000000D03*
%TD*%
%TO.C,*%
X95000000Y-5000000D03*
%TD*%
%TO.C,*%
X95000000Y-145000000D03*
%TD*%
%TO.C,*%
X5000000Y-145000000D03*
%TD*%
M02*
